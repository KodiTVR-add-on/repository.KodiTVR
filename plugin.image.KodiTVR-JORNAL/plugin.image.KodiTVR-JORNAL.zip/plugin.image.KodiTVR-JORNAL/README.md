# plugin.image.KodiTVR-JORNAL

Daily portuguese newspapper covers in Kodi

* Screenshots

![Screenshot screensaver](https://github.com/KodiTVR-add-on/plugin.image.KodiTVR-JORNAL/master/resources/images/screenshot-01.jpg?raw=true)

![Screenshot screensaver](https://github.com/KodiTVR-add-on/plugin.image.KodiTVR-JORNAL/master/resources/images/screenshot-02.jpg?raw=true)

![Screenshot screensaver](https://github.com/KodiTVR-add-on/plugin.image.KodiTVR-JORNAL/master/resources/images/screenshot-03.jpg?raw=true)

![Screenshot screensaver](https://github.com/KodiTVR-add-on/plugin.image.KodiTVR-JORNAL/master/resources/images/screenshot-04.jpg?raw=true)
