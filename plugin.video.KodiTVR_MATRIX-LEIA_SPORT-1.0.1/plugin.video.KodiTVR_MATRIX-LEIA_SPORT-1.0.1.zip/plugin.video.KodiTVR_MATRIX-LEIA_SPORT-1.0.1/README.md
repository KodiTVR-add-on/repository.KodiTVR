# KodiTVR_MATRIX-LEIA_SPORT

Simple Kodi add-on that scrapes a few sports sites for live streams, replays and highlights.
[PT] Simples Kodi add-on que remove alguns sites de desportos para transmissões ao vivo, replays e destaques.

**Disclaimer**:
The author does not host or distribute any of the content displayed by this add-on. The author does not have any affiliation with the content provider.
This addon acts merely as a browser for sites publically available on the internet which the author has no control of.

[PT] O autor não hospeda ou distribui qualquer conteúdo exibido por este add-on. O autor não tem nenhuma afiliação com o provedor de conteúdo.
Este add-on atua meramente como um navegador para sites publicamente disponíveis na Internet sobre os quais o autor não tem controle.